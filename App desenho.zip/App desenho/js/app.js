// Inicializar canvas
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

// Variáveis de estado do desenho
let isDrawing = false;
let lastX = 0;
let lastY = 0;


// Seletores do menu
const pencilTool = document.getElementById('pencilTool');
const eraserTool = document.getElementById('eraserTool');
const colorPicker = document.getElementById('colorPicker');
const lineWidth = document.getElementById('lineWidth');
const canvasWidthInput = document.getElementById('canvasWidth');
const canvasHeightInput = document.getElementById('canvasHeight');
const resizeCanvasButton = document.getElementById('resizeCanvas');
const saveButton = document.getElementById('saveButton');
const loadButton = document.getElementById('loadButton');
const fileInput = document.getElementById('fileInput');

// Variáveis de estado
let currentTool = 'pencil';
let strokeColor = '#000000';
let strokeWidth = 5;

let startX = 0;
let startY = 0;
let isDrawingShape = false;

const lineTool = document.getElementById('lineTool');
const rectangleTool = document.getElementById('rectangleTool');
const circleTool = document.getElementById('circleTool');

// Atualiza as configurações de desenho
colorPicker.addEventListener('input', (e) => {
    strokeColor = e.target.value;
});

lineWidth.addEventListener('input', (e) => {
    strokeWidth = e.target.value;
});

// Ferramentas
pencilTool.addEventListener('click', () => {
    currentTool = 'pencil';
});

eraserTool.addEventListener('click', () => {
    currentTool = 'eraser';
});

// Seleção de ferramentas de formas
lineTool.addEventListener('click', () => {
    currentTool = 'line';
});

rectangleTool.addEventListener('click', () => {
    currentTool = 'rectangle';
});

circleTool.addEventListener('click', () => {
    currentTool = 'circle';
});


// Evento de desenho
// Variável para armazenar uma cópia temporária do estado do canvas
let tempCanvas;

// Função para salvar o estado atual do canvas
function saveCanvasState() {
    tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    tempCanvas.getContext('2d').drawImage(canvas, 0, 0);
}

// Função para restaurar o estado temporário do canvas
function restoreCanvasState() {
    if (tempCanvas) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(tempCanvas, 0, 0);
    }
}

canvas.addEventListener('mousedown', (e) => {
    isDrawing = true;
    isDrawingShape = currentTool === 'line' || currentTool === 'rectangle' || currentTool === 'circle';

    [startX, startY] = [e.offsetX, e.offsetY];

    if (isDrawingShape) {
        saveCanvasState(); // Salva o estado do canvas
    } else {
        [lastX, lastY] = [e.offsetX, e.offsetY];
    }

});

// Evento mousemove para ajustar dinamicamente a forma
canvas.addEventListener('mousemove', (e) => {
    if (!isDrawing) return;

    const currentX = e.offsetX;
    const currentY = e.offsetY;

    if (currentTool === 'eraser') {
        ctx.globalCompositeOperation = 'destination-out'; // Modo de apagar
        ctx.lineWidth = strokeWidth;
        ctx.beginPath();
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(currentX, currentY);
        ctx.stroke();
        ctx.globalCompositeOperation = 'source-over'; // Retorna ao modo normal
    } else if (isDrawingShape) {
        // Restaura o estado do canvas antes de redesenhar a forma
        restoreCanvasState();
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        if (currentTool === 'rectangle') {
            const width = currentX - startX;
            const height = currentY - startY;
            ctx.strokeRect(startX, startY, width, height);
        } else if (currentTool === 'line') {
            ctx.beginPath();
            ctx.moveTo(startX, startY);
            ctx.lineTo(currentX, currentY);
            ctx.stroke();
        } else if (currentTool === 'circle') {
            const radius = Math.sqrt(Math.pow(currentX - startX, 2) + Math.pow(currentY - startY, 2));
            ctx.beginPath();
            ctx.arc(startX, startY, radius, 0, Math.PI * 2);
            ctx.stroke();
        }
    } else {
        ctx.beginPath();
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(currentX, currentY);
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;
        ctx.stroke();
    }

    [lastX, lastY] = [currentX, currentY];

    // ctx.beginPath();
    // ctx.moveTo(lastX, lastY);
    // ctx.lineTo(e.offsetX, e.offsetY);
    // ctx.stroke();
    // [lastX, lastY] = [e.offsetX, e.offsetY];
});

// Evento mouseup para finalizar o desenho
canvas.addEventListener('mouseup', (e) => {
    if (isDrawingShape) {
        restoreCanvasState(); // Restaura o estado antes de finalizar

        const endX = e.offsetX;
        const endY = e.offsetY;

        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;

        if (currentTool === 'line') {
            ctx.beginPath();
            ctx.moveTo(startX, startY);
            ctx.lineTo(endX, endY);
            ctx.stroke();
        } else if (currentTool === 'rectangle') {
            const width = endX - startX;
            const height = endY - startY;
            ctx.strokeRect(startX, startY, width, height);
        } else if (currentTool === 'circle') {
            const radius = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
            ctx.beginPath();
            ctx.arc(startX, startY, radius, 0, Math.PI * 2);
            ctx.stroke();
        }
    }

    isDrawing = false;
    isDrawingShape = false;
});
// Evento mouseout para interromper o desenho se o cursor sair da área
canvas.addEventListener('mouseout', () => (isDrawing = false));

// Função para redimensionar canvas
resizeCanvasButton.addEventListener('click', () => {
    const newWidth = parseInt(canvasWidthInput.value);
    const newHeight = parseInt(canvasHeightInput.value);

    // Salva o estado atual do canvas
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    tempCanvas.getContext('2d').drawImage(canvas, 0, 0);

    // Redimensiona o canvas
    canvas.width = newWidth;
    canvas.height = newHeight;

    // Restaura o estado salvo
    ctx.drawImage(tempCanvas, 0, 0);
});

// Salvar o desenho
saveButton.addEventListener('click', () => {
    const dataURL = canvas.toDataURL();
    const link = document.createElement('a');
    link.download = 'desenho.png';
    link.href = dataURL;
    link.click();
});

// Abrir um desenho
loadButton.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        };
        img.src = event.target.result;
    };
    reader.readAsDataURL(file);
});
