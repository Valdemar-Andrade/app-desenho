import http.server
import socketserver
import json
import mysql.connector
import os

# Configuracoes do banco de dados
db_config = {
    'host': 'localhost',
    'user': 'root',  # Substitua pelo seu usuario do MySQL
    'password': 'vava123456789',  # Substitua pela sua senha do MySQL
    'database': 'desenho_app'
}

# Funcao para validar o login
def validar_login(username, password):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        query = "SELECT * FROM usuarios WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        result = cursor.fetchone()
        cursor.close()
        conn.close()
        return result if result else None
    except mysql.connector.Error as err:
        print(f"Erro ao conectar ao banco de dados: {err}")
        return False

# Funcao para criar uma nova conta
def criar_conta(username, senha):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        query = "INSERT INTO usuarios (username, password) VALUES (%s, %s)"
        cursor.execute(query, (username, senha))
        conn.commit()
        cursor.close()
        conn.close()
        return {'success': True, 'message': 'Conta criada com sucesso!'}
    except mysql.connector.Error as err:
        print(f"Erro ao criar conta: {err}")
        return {'success': False, 'message': 'Erro ao criar conta. Tente novamente.'}

def registrar_historico(usuario_id, acao):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        query = "INSERT INTO historico (usuario_id, acao) VALUES (%s, %s)"
        cursor.execute(query, (usuario_id, acao))
        conn.commit()
        cursor.close()
        conn.close()
    except mysql.connector.Error as err:
        print(f"Erro ao registrar histórico: {err}")

# Funcao para salvar o desenho
def salvar_desenho(usuario_id, shapes):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        query = "INSERT INTO desenhos (usuario_id, shapes) VALUES (%s, %s) ON DUPLICATE KEY UPDATE shapes = %s"
        cursor.execute(query, (usuario_id, json.dumps(shapes), json.dumps(shapes)))
        conn.commit()
        cursor.close()
        conn.close()
        return {'success': True, 'message': 'Desenho salvo com sucesso!'}
    except mysql.connector.Error as err:
        print(f"Erro ao salvar desenho: {err}")
        return {'success': False, 'message': 'Erro ao salvar desenho.'}

# Funcao para carregar o desenho
def carregar_desenho(usuario_id):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        query = "SELECT shapes FROM desenhos WHERE usuario_id = %s ORDER BY id DESC LIMIT 1"
        cursor.execute(query, (usuario_id,))
        result = cursor.fetchone()
        cursor.close()
        conn.close()
        if result:
            return {'success': True, 'shapes': json.loads(result[0])}
        else:
            return {'success': True, 'shapes': []}  # Retorna um array vazio se não houver desenho salvo
    except mysql.connector.Error as err:
        print(f"Erro ao carregar desenho: {err}")
        return {'success': False, 'message': 'Erro ao carregar desenho.'}

# Classe para manipular as requisicoes HTTP
class LoginHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/' or self.path == '/login':
            self.path = '/login.html'
        elif self.path == '/desenho':
            self.path = '/desenho.html'
        elif self.path == '/criar-conta':
            self.path = '/criar-conta.html'
        elif self.path.startswith('/historico-desenhos'):
            usuario_id = self.path.split('=')[1]  # Obtém o ID do usuário da query string
            try:
                conn = mysql.connector.connect(**db_config)
                cursor = conn.cursor()
                query = "SELECT id, shapes FROM desenhos WHERE usuario_id = %s ORDER BY id DESC"
                cursor.execute(query, (usuario_id,))
                drawings = cursor.fetchall()
                cursor.close()
                conn.close()

                # Formata os desenhos para retornar ao frontend
                drawings_list = [{'id': drawing[0], 'shapes': json.loads(drawing[1])} for drawing in drawings]
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': True, 'drawings': drawings_list}).encode())
            except mysql.connector.Error as err:
                print(f"Erro ao buscar histórico de desenhos: {err}")
                self.send_error(500, "Erro ao buscar histórico de desenhos")
        elif self.path.startswith('/carregar-desenho-historico/'):
            try:
                # Extrai o ID do desenho da URL
                parts = self.path.split('/')
                if len(parts) < 3:
                    self.send_error(400, "ID do desenho não fornecido")
                    return

                drawing_id = parts[2]  # Obtém o ID do desenho
                if not drawing_id.isdigit():  # Verifica se o ID é um número válido
                    self.send_error(400, "ID do desenho inválido")
                    return

                # Conecta ao banco de dados e busca o desenho
                conn = mysql.connector.connect(**db_config)
                cursor = conn.cursor()
                query = "SELECT shapes FROM desenhos WHERE id = %s"
                cursor.execute(query, (drawing_id,))
                result = cursor.fetchone()
                cursor.close()
                conn.close()

                if result:
                    # Retorna o desenho encontrado
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'success': True, 'shapes': json.loads(result[0])}).encode())
                else:
                    self.send_error(404, "Desenho não encontrado")
            except mysql.connector.Error as err:
                print(f"Erro ao carregar desenho: {err}")
                self.send_error(500, "Erro ao carregar desenho")
        elif self.path == '/carregar-desenho':
            usuario_id = self.headers.get('usuario_id')
            if not usuario_id:
                self.send_response(400)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'success': False, 'message': 'Usuário não especificado'}).encode())
                return

            resultado = carregar_desenho(usuario_id)
            self.send_response(200 if resultado['success'] else 500)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(resultado).encode())
        else:
            if self.path.endswith('.html') or self.path.endswith('.css') or self.path.endswith('.js') or self.path.endswith('.png') or self.path.endswith('.jpeg') or self.path.endswith('.jpg'):
                try:
                    with open(os.path.join(os.getcwd(), self.path[1:]), 'rb') as file:
                        self.send_response(200)
                        if self.path.endswith('.html'):
                            self.send_header('Content-type', 'text/html')
                        elif self.path.endswith('.css'):
                            self.send_header('Content-type', 'text/css')
                        elif self.path.endswith('.js'):
                            self.send_header('Content-type', 'application/javascript')
                        elif self.path.endswith('.png'):
                            self.send_header('Content-type', 'image/png')
                        elif self.path.endswith('.jpg') or self.path.endswith('.jpeg'):
                            self.send_header('Content-type', 'image/jpeg')
                        self.end_headers()
                        self.wfile.write(file.read())
                except FileNotFoundError:
                    self.send_error(404, "Arquivo não encontrado")
            else:
                self.send_error(404, "Rota não encontrada")

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        data = json.loads(post_data)

        if self.path == '/login':
            username = data.get('username')
            password = data.get('password')
            result = validar_login(username, password)

            if result:
                self.send_response(200)
                response = {'success': True, 'message': 'Login válido', 'usuario_id': result[0]}
            else:
                self.send_response(401)
                response = {'success': False, 'message': 'Usuário ou senha incorretos'}

        elif self.path == '/criar-conta':
            username = data.get('username')
            password = data.get('password')
            resultado = criar_conta(username, password)
            if resultado['success']:
                self.send_response(200)
                response = {'success': True, 'message': resultado['message']}
            else:
                self.send_response(400)
                response = {'success': False, 'message': resultado['message']}

        elif self.path == '/registrar-historico':
            usuario_id = data.get('usuario_id')
            acao = data.get('acao')
            registrar_historico(usuario_id, acao)
            self.send_response(200)
            response = {'success': True}

        elif self.path == '/salvar-desenho':
            usuario_id = data.get('usuario_id')
            shapes = data.get('shapes')
            resultado = salvar_desenho(usuario_id, shapes)
            self.send_response(200 if resultado['success'] else 500)
            response = resultado

        else:
            self.send_error(404, "Rota não encontrada")
            return

        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(response).encode())

# Inicia o servidor
PORT = 8000
with socketserver.TCPServer(("", PORT), LoginHandler) as httpd:
    print(f"Servidor rodando na porta {PORT}")
    httpd.serve_forever()