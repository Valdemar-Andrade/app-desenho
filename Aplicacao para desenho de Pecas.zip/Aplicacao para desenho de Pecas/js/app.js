// Inicializar canvas
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

// Variáveis de estado do desenho
let isDrawing = false;
let isDragging = false;
let selectedShape = null;
let offsetX, offsetY;

// Lista para armazenar as formas desenhadas
let shapes = [];

// Seletores do menu
const pencilTool = document.getElementById('pencilTool');
const eraserTool = document.getElementById('eraserTool');
const selectTool = document.getElementById('selectTool');
const paintTool = document.getElementById('paintTool');
const colorPicker = document.getElementById('colorPicker');
const lineWidth = document.getElementById('lineWidth');
const canvasWidthInput = document.getElementById('canvasWidth');
const canvasHeightInput = document.getElementById('canvasHeight');
const resizeCanvasButton = document.getElementById('resizeCanvas');
const saveButton = document.getElementById('saveButton');
const loadButton = document.getElementById('loadButton');
const fileInput = document.getElementById('fileInput');
const lineTool = document.getElementById('lineTool');
const rectangleTool = document.getElementById('rectangleTool');
const circleTool = document.getElementById('circleTool');
const clearButton = document.getElementById('clearButton');

// Variáveis de estado
let currentTool = 'pencil';
let strokeColor = '#000000';
let strokeWidth = 5; // Valor inicial da espessura do traço

// Atualiza a espessura do traço quando o scroller é alterado
lineWidth.addEventListener('input', (e) => {
    strokeWidth = parseInt(e.target.value); // Atualiza a variável strokeWidth
});

// Atualiza a cor do traço quando o seletor de cores é alterado
colorPicker.addEventListener('input', (e) => {
    strokeColor = e.target.value; // Atualiza a variável strokeColor
});

// Função para desenhar todas as formas
function drawShapes() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    shapes.forEach(shape => {
        // Desenha o preenchimento associado à forma
        if (shape.fill) {
            ctx.fillStyle = shape.fill.color;
            shape.fill.pixels.forEach(pixel => {
                ctx.fillRect(pixel.x, pixel.y, 1, 1); // Preenche cada pixel
            });
        }

        // Desenha a forma
        ctx.strokeStyle = shape.color;
        ctx.lineWidth = shape.width;
        if (shape.type === 'line') {
            ctx.beginPath();
            ctx.moveTo(shape.startX, shape.startY);
            ctx.lineTo(shape.endX, shape.endY);
            ctx.stroke();
        } else if (shape.type === 'rectangle') {
            ctx.strokeRect(shape.startX, shape.startY, shape.width, shape.height);
        } else if (shape.type === 'circle') {
            ctx.beginPath();
            ctx.arc(shape.startX, shape.startY, shape.radius, 0, Math.PI * 2);
            ctx.stroke();
        } else if (shape.type === 'pencil') {
            ctx.beginPath();
            ctx.moveTo(shape.points[0].x, shape.points[0].y);
            shape.points.forEach(point => {
                ctx.lineTo(point.x, point.y);
            });
            ctx.stroke();
        }
    });
}

// Função para verificar se o clique foi em uma forma
function getShapeAt(x, y) {
    for (let i = shapes.length - 1; i >= 0; i--) {
        const shape = shapes[i];
        if (shape.type === 'line') {
            // Verifica se o clique foi próximo à linha
            const dx = shape.endX - shape.startX;
            const dy = shape.endY - shape.startY;
            const length = Math.sqrt(dx * dx + dy * dy);
            const pointDistance =
                (Math.abs(dy * x - dx * y + shape.endX * shape.startY - shape.endY * shape.startX)) / length;
            if (pointDistance < 5) {
                return shape;
            }
        } else if (shape.type === 'rectangle') {
            // Verifica se o clique foi dentro do retângulo
            if (x >= shape.startX && x <= shape.startX + shape.width &&
                y >= shape.startY && y <= shape.startY + shape.height) {
                return shape;
            }
        } else if (shape.type === 'circle') {
            // Verifica se o clique foi dentro do círculo
            const distance = Math.sqrt(Math.pow(x - shape.startX, 2) + Math.pow(y - shape.startY, 2));
            if (distance <= shape.radius) {
                return shape;
            }
        } else if (shape.type === 'pencil') {
            // Verifica se o clique foi próximo a algum ponto do traço do pincel
            for (let j = 0; j < shape.points.length; j++) {
                const point = shape.points[j];
                const distance = Math.sqrt(Math.pow(x - point.x, 2) + Math.pow(y - point.y, 2));
                if (distance < 10) { // Tolerância de 10 pixels
                    return shape;
                }
            }
        }
    }
    return null;
}

// Função para preenchimento por inundação (flood fill)
function floodFill(x, y, targetColor, fillColor) {
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    const startPos = (y * canvas.width + x) * 4;

    const startColor = {
        r: pixels[startPos],
        g: pixels[startPos + 1],
        b: pixels[startPos + 2],
        a: pixels[startPos + 3]
    };

    if (
        startColor.r === fillColor.r &&
        startColor.g === fillColor.g &&
        startColor.b === fillColor.b &&
        startColor.a === fillColor.a
    ) {
        return;
    }

    if (
        startColor.r !== targetColor.r ||
        startColor.g !== targetColor.g ||
        startColor.b !== targetColor.b ||
        startColor.a !== targetColor.a
    ) {
        return;
    }

    const stack = [{ x, y }];
    const filledPixels = []; // Armazena os pixels preenchidos

    while (stack.length > 0) {
        const { x, y } = stack.pop();
        const pos = (y * canvas.width + x) * 4;

        if (
            pixels[pos] === targetColor.r &&
            pixels[pos + 1] === targetColor.g &&
            pixels[pos + 2] === targetColor.b &&
            pixels[pos + 3] === targetColor.a
        ) {
            pixels[pos] = fillColor.r;
            pixels[pos + 1] = fillColor.g;
            pixels[pos + 2] = fillColor.b;
            pixels[pos + 3] = fillColor.a;

            filledPixels.push({ x, y }); // Armazena o pixel preenchido

            if (x > 0) stack.push({ x: x - 1, y });
            if (x < canvas.width - 1) stack.push({ x: x + 1, y });
            if (y > 0) stack.push({ x, y: y - 1 });
            if (y < canvas.height - 1) stack.push({ x, y: y + 1 });
        }
    }

    // Atualiza o canvas com os pixels modificados
    ctx.putImageData(imageData, 0, 0);

    // Encontra a forma que foi preenchida
    const filledShape = shapes.find(shape => {
        if (shape.type === 'circle') {
            const distance = Math.sqrt(Math.pow(x - shape.startX, 2) + Math.pow(y - shape.startY, 2));
            return distance <= shape.radius;
        }
        // Adicione verificações para outras formas (retângulo, linha, etc.)
        return false;
    });

    // Associa o preenchimento à forma
    if (filledShape) {
        filledShape.fill = {
            type: 'fill',
            color: strokeColor, // Usa a cor atual do traço
            pixels: filledPixels // Armazena os pixels preenchidos
        };
    }
}

// Função para converter uma cor hexadecimal para RGBA
function hexToRgba(hex) {
    // Remove o caractere '#' se presente
    hex = hex.replace('#', '');

    // Converte a cor hexadecimal para valores RGB
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);

    // Retorna a cor no formato RGBA
    return { r, g, b, a: 255 };
}

// Evento de clique no canvas
canvas.addEventListener('mousedown', (e) => {
    const x = e.offsetX;
    const y = e.offsetY;

    if (currentTool === 'paint') {
        // Obtém a cor do pixel clicado
        const imageData = ctx.getImageData(x, y, 1, 1);
        const targetColor = {
            r: imageData.data[0],
            g: imageData.data[1],
            b: imageData.data[2],
            a: imageData.data[3]
        };

        // Converte a cor de preenchimento (strokeColor) para o formato RGBA
        const fillColor = hexToRgba(strokeColor);

        // Executa o algoritmo de flood fill
        floodFill(x, y, targetColor, fillColor);
    }

    if (currentTool === 'select') {
        // Verifica se o clique foi em uma forma
        selectedShape = getShapeAt(x, y);
        if (selectedShape) {
            isDragging = true;
            offsetX = x - (selectedShape.type === 'pencil' ? selectedShape.points[0].x : selectedShape.startX);
            offsetY = y - (selectedShape.type === 'pencil' ? selectedShape.points[0].y : selectedShape.startY);
        }
    } else {
        isDrawing = true;
        if (currentTool === 'line') {
            shapes.push({
                type: 'line',
                startX: x,
                startY: y,
                endX: x,
                endY: y,
                color: strokeColor,
                width: strokeWidth
            });
        } else if (currentTool === 'rectangle') {
            shapes.push({
                type: 'rectangle',
                startX: x,
                startY: y,
                width: 0,
                height: 0,
                color: strokeColor,
                width: strokeWidth
            });
        } else if (currentTool === 'circle') {
            shapes.push({
                type: 'circle',
                startX: x,
                startY: y,
                radius: 0,
                color: strokeColor,
                width: strokeWidth,
                fill: null // Inicialmente sem preenchimento
            });
        } else if (currentTool === 'pencil') {
            // Adiciona um novo traço de pincel
            shapes.push({
                type: 'pencil',
                points: [{ x, y }], // Armazena os pontos do traço
                color: strokeColor,
                width: strokeWidth
            });
        }
    }
});

// Evento de movimento do mouse (parte da borracha)
canvas.addEventListener('mousemove', (e) => {
    const x = e.offsetX;
    const y = e.offsetY;

    if (isDragging && selectedShape) {
        // Calcula o deslocamento
        const deltaX = x - offsetX - selectedShape.startX;
        const deltaY = y - offsetY - selectedShape.startY;

        // Move a forma
        selectedShape.startX += deltaX;
        selectedShape.startY += deltaY;

        // Move o preenchimento associado (se houver)
        if (selectedShape.fill) {
            selectedShape.fill.pixels.forEach(pixel => {
                pixel.x += deltaX;
                pixel.y += deltaY;
            });
        }

        // Atualiza a posição da forma selecionada
        if (selectedShape.type === 'pencil') {
            // Move todos os pontos do traço do pincel
            const deltaX = x - offsetX - selectedShape.points[0].x;
            const deltaY = y - offsetY - selectedShape.points[0].y;
            selectedShape.points.forEach(point => {
                point.x += deltaX;
                point.y += deltaY;
            });
        } else {
            // Move a forma (linha, retângulo, círculo)
            const deltaX = x - offsetX - selectedShape.startX;
            const deltaY = y - offsetY - selectedShape.startY;
            selectedShape.startX += deltaX;
            selectedShape.startY += deltaY;
            if (selectedShape.type === 'line') {
                selectedShape.endX += deltaX;
                selectedShape.endY += deltaY;
            }
        }
        // Redesenha o canvas
        drawShapes();
    } else if (isDrawing) {
        if (currentTool === 'eraser') {
            const eraseRadius = strokeWidth / 2; // Raio da borracha

            // Filtra as formas para remover as que estão dentro da área de apagamento
            shapes = shapes.filter(shape => {
                if (shape.type === 'pencil') {
                    // Remove pontos do traço que estão dentro da área de apagamento
                    shape.points = shape.points.filter(point => {
                        const distance = Math.sqrt(Math.pow(x - point.x, 2) + Math.pow(y - point.y, 2));
                        return distance > eraseRadius; // Mantém apenas pontos fora da área de apagamento
                    });
                    return shape.points.length > 0; // Mantém o traço apenas se ainda houver pontos
                } else if (shape.type === 'line') {
                    // Verifica se a borracha está próxima da linha
                    const dx = shape.endX - shape.startX;
                    const dy = shape.endY - shape.startY;
                    const length = Math.sqrt(dx * dx + dy * dy);
                    const pointDistance =
                        (Math.abs(dy * x - dx * y + shape.endX * shape.startY - shape.endY * shape.startX)) / length;
                    return pointDistance > eraseRadius; // Mantém a linha apenas se estiver fora da área de apagamento
                } else if (shape.type === 'rectangle') {
                    // Verifica se a borracha está dentro do retângulo
                    const isInside =
                        x >= shape.startX - eraseRadius &&
                        x <= shape.startX + shape.width + eraseRadius &&
                        y >= shape.startY - eraseRadius &&
                        y <= shape.startY + shape.height + eraseRadius;
                    return !isInside; // Mantém o retângulo apenas se a borracha estiver fora
                } else if (shape.type === 'circle') {
                    // Verifica se a borracha está próxima da borda do círculo
                    const distance = Math.sqrt(Math.pow(x - shape.startX, 2) + Math.pow(y - shape.startY, 2));
                    return distance > shape.radius + eraseRadius; // Mantém o círculo apenas se estiver fora da área de apagamento
                }
                return true; // Mantém outras formas (se houver)
            });

            drawShapes(); // Redesenha o canvas sem as formas apagadas
        } else {
            const lastShape = shapes[shapes.length - 1];
            if (currentTool === 'line') {
                lastShape.endX = x;
                lastShape.endY = y;
            } else if (currentTool === 'rectangle') {
                lastShape.width = x - lastShape.startX;
                lastShape.height = y - lastShape.startY;
            } else if (currentTool === 'circle') {
                lastShape.radius = Math.sqrt(Math.pow(x - lastShape.startX, 2) + Math.pow(y - lastShape.startY, 2));
            } else if (currentTool === 'pencil') {
                // Adiciona um novo ponto ao traço do pincel
                lastShape.points.push({ x, y });
            }
            drawShapes();
        }
    }
});

// Evento de soltar o mouse
canvas.addEventListener('mouseup', () => {
    isDrawing = false;
    isDragging = false;
    selectedShape = null;
});

// Evento de sair do canvas
canvas.addEventListener('mouseout', () => {
    isDrawing = false;
    isDragging = false;
    selectedShape = null;
});

// Ferramentas
pencilTool.addEventListener('click', () => {
    currentTool = 'pencil';
});

eraserTool.addEventListener('click', () => {
    currentTool = 'eraser';
});

selectTool.addEventListener('click', () => {
    currentTool = 'select';
});

lineTool.addEventListener('click', () => {
    currentTool = 'line';
});

rectangleTool.addEventListener('click', () => {
    currentTool = 'rectangle';
});

circleTool.addEventListener('click', () => {
    currentTool = 'circle';
});

paintTool.addEventListener('click', () => {
    currentTool = 'paint'; // Define a ferramenta atual como "paint"
});

// Limpar o canvas
clearButton.addEventListener('click', () => {
    shapes = [];
    drawShapes();
});

// Redimensionar canvas
resizeCanvasButton.addEventListener('click', () => {
    const newWidth = parseInt(canvasWidthInput.value);
    const newHeight = parseInt(canvasHeightInput.value);

    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    tempCanvas.getContext('2d').drawImage(canvas, 0, 0);

    canvas.width = newWidth;
    canvas.height = newHeight;

    ctx.drawImage(tempCanvas, 0, 0);
});

// Salvar o desenho
saveButton.addEventListener('click', () => {
    // Verifica se há formas desenhadas no canvas
    if (shapes.length === 0) {
        alert("Não há nada para salvar. Desenhe algo primeiro!");
        return;
    }

    // Converte o canvas para uma imagem
    const dataURL = canvas.toDataURL();

    // Cria um link de download
    const link = document.createElement('a');
    link.download = 'desenho.png'; // Nome do arquivo
    link.href = dataURL; // URL da imagem

    // Simula o clique no link para iniciar o download
    document.body.appendChild(link); // Adiciona o link ao DOM
    link.click();
    document.body.removeChild(link); // Remove o link do DOM

    // Registra a ação no histórico
    const usuario_id = localStorage.getItem('usuario_id');
    const username = localStorage.getItem('username');
    if (usuario_id) {
        fetch('/registrar-historico', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ usuario_id, acao: `${username} salvou um desenho` })
        })
            .then(response => response.json())
            .then(data => console.log(data))
            .catch(error => console.error('Erro ao registrar histórico:', error));
    }

    // Salva o estado do desenho no servidor
    fetch('/salvar-desenho', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ usuario_id, shapes })
    })
        .then(response => response.json())
        .then(data => console.log(data))
        .catch(error => console.error('Erro ao salvar desenho:', error));
});

// Abrir um desenho
loadButton.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];  // Pega o arquivo selecionado
    if (!file) return;

    const reader = new FileReader();  // Cria um FileReader para ler o arquivo
    reader.onload = (event) => {
        const img = new Image();  // Cria uma nova imagem
        img.onload = () => {
            // Limpa o canvas e desenha a imagem carregada
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        };
        img.src = event.target.result;  // Define a fonte da imagem como o arquivo carregado
    };
    reader.readAsDataURL(file);  // Lê o arquivo como uma URL de dados
});

// Carregar o desenho ao fazer login
function carregarDesenho(usuario_id) {
    fetch(`/carregar-desenho`, {
        method: 'GET',
        headers: {
            'usuario_id': usuario_id
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                shapes = data.shapes; // Atualiza a lista de formas
                drawShapes(); // Redesenha o canvas
            }
        })
        .catch(error => console.error('Erro ao carregar desenho:', error));
}

const user_id = localStorage.getItem('usuario_id');
if (user_id) {
    carregarDesenho(user_id);
}